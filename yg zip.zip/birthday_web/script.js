const intro = document.getElementById('intro');
const content = document.getElementById('content');
const music = document.getElementById('bgMusic');
const openBtn = document.getElementById('openBtn');

openBtn.addEventListener('click', async () => {
  intro.classList.add('hidden');
  content.classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Musik mulai saat tombol Open Your Gift ditekan.
  try {
    await music.play();
  } catch (error) {
    console.log('Musik belum bisa diputar. Periksa file assets/lagu.mp3.', error);
  }

  makePetals();
});

function makePetals() {
  const holder = document.getElementById('petals');
  for (let i = 0; i < 24; i++) {
    const p = document.createElement('span');
    p.className = 'petal';
    p.textContent = Math.random() > 0.5 ? '♥' : '✿';
    p.style.left = Math.random() * 100 + 'vw';
    p.style.animationDuration = (6 + Math.random() * 7) + 's';
    p.style.animationDelay = (Math.random() * 5) + 's';
    p.style.fontSize = (10 + Math.random() * 14) + 'px';
    holder.appendChild(p);
    setTimeout(() => p.remove(), 14000);
  }
}

function createLoveTree() {
  const container = document.querySelector(".heart-tree");
  if (!container || container.querySelector(".love-tree-svg")) return;

  const ns = "http://www.w3.org/2000/svg";

  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 360 390");
  svg.setAttribute("class", "love-tree-svg");

  const makePath = (d, width, color1, color2) => {
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", d);
    p.setAttribute("fill", "none");
    p.setAttribute("stroke", color1);
    p.setAttribute("stroke-width", width);
    p.setAttribute("stroke-linecap", "round");
    p.setAttribute("stroke-linejoin", "round");
    p.style.filter = `drop-shadow(2px 3px 2px ${color2})`;
    svg.appendChild(p);
  };

  // BATANG UTAMA
  makePath("M180 385 C172 330 190 290 180 245 C170 215 177 185 180 165", 19, "#936052", "#70443b");
  makePath("M180 385 C172 330 190 290 180 245", 5, "#d5a18b", "#a66b5e");

  // CABANG KIRI
  makePath("M180 285 C145 265 120 235 93 205 C80 190 68 180 48 175", 12, "#a66b5e", "#70443b");
  makePath("M145 255 C145 225 130 205 115 185 C105 170 100 155 102 140", 8, "#b77d6d", "#70443b");
  makePath("M110 220 C85 215 73 195 65 180", 6, "#bd8875", "#70443b");

  // CABANG KANAN
  makePath("M180 280 C215 255 240 230 270 200 C285 185 300 175 318 168", 12, "#a66b5e", "#70443b");
  makePath("M215 250 C220 220 235 195 250 175 C260 160 260 145 255 132", 8, "#b77d6d", "#70443b");
  makePath("M260 210 C285 205 298 188 306 174", 6, "#bd8875", "#70443b");

  // CABANG ATAS
  makePath("M180 220 C155 195 145 165 145 135", 7, "#b77d6d", "#70443b");
  makePath("M180 215 C205 190 215 160 215 130", 7, "#b77d6d", "#70443b");

  // SATU MAHKOTA HATI BESAR
const crown = document.createElementNS(ns, "path");

crown.setAttribute(
  "d",
  "M180 245 C155 220 45 155 45 85 C45 35 105 15 145 45 C160 55 172 70 180 85 C188 70 200 55 215 45 C255 15 315 35 315 85 C315 155 205 220 180 245 Z"
);

crown.setAttribute("fill", "#ed91ae");
crown.setAttribute("stroke", "#d96f94");
crown.setAttribute("stroke-width", "2");
crown.style.filter = "drop-shadow(0 5px 8px #d96f9466)";
crown.style.animation = "heartGrow 1.5s ease both";

svg.appendChild(crown);
  container.querySelector(".trunk")?.remove();

  container.appendChild(svg);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", createLoveTree);
} else {
  createLoveTree();
}

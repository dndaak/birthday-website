WEBSITE ULANG TAHUN - VERSI DIPERBAIKI

1. Buka folder birthday_web di VS Code.
2. Masukkan 9 foto ke folder assets dengan nama:
   foto1.png, foto2.png, foto3.png, foto4.png, foto5.png,
   foto6.png, foto7.png, foto8.png, foto9.png
   Jika file foto kamu JPG, ubah ekstensi di index.html agar sesuai.
3. Masukkan file lagu ke folder assets dan beri nama lagu.mp3.
4. Buka index.html dengan Live Server.
5. Klik tombol Open your gift. Musik akan dicoba diputar saat tombol ditekan.

Catatan:
- Tombol Play Music/Pause Music sudah dihapus.
- Galeri berisi 9 foto (3 kolom x 3 baris).
- Tulisan Ma Love berwarna pink.
- Browser tetap harus mengizinkan audio dan file assets/lagu.mp3 harus tersedia.
